﻿using SportGooodsFinally.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SportGooodsFinally.Context;

namespace SportGooodsFinally.Presentation
{
    /// <summary>
    /// Логика взаимодействия для GoodsControl.xaml
    /// </summary>
    public partial class GoodsControl : Window
    {
            public List<Product> Products { get; private set; }

            public GoodsControl()
            {
                InitializeComponent();
            }

            public void Create()
            {
                try
                {
                    using (ApplicationContext context = new ApplicationContext())
                    {
                        var productName = NameTextBox.Text;
                        var productManufacturer = ManufacturerTextBox.Text;

                        if (!string.IsNullOrEmpty(productName) && !string.IsNullOrEmpty(productManufacturer))
                        {
                            context.Products.Add(new Product() { ProductName = productName, ProductManufacturer = productManufacturer });
                            context.SaveChanges();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при создании продукта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            public void Read()
            {
                try
                {
                    using (ApplicationContext context = new ApplicationContext())
                    {
                        Products = context.Products.ToList();
                        ItemList.ItemsSource = Products;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при чтении продуктов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

        public void Update()
        {
            try
            {
                if (ItemList.SelectedItem is Product selectedProduct)
                {
                    using (ApplicationContext context = new ApplicationContext())
                    {
                        var productName = NameTextBox.Text;
                        var productManufacturer = ManufacturerTextBox.Text;
                        var productArticleNumber = ProductArticleNumber.Text;

                        if (!string.IsNullOrEmpty(productName) && !string.IsNullOrEmpty(productManufacturer))
                        {
                            Product product = context.Products.Find(selectedProduct.ProductArticleNumber);
                            if (product != null)
                            {
                                product.ProductArticleNumber = productArticleNumber;
                                product.ProductName = productName;
                                product.ProductManufacturer = productManufacturer;
                                context.SaveChanges();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении продукта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void Delete()
        {
            try
            {
                if (ItemList.SelectedItem is Product selectedProduct)
                {
                    using (ApplicationContext context = new ApplicationContext())
                    {
                        Product product = context.Products.Find(selectedProduct.ProductArticleNumber);
                        if (product != null)
                        {
                            context.Remove(product);
                            context.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении продукта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
            {
                Create();
            }

            private void ReadButton_Click(object sender, RoutedEventArgs e)
            {
                Read();
            }

            //private void UpdateButton_Click(object sender, RoutedEventArgs e)
            //{
            //    Update();
            //}

            //private void DeleteButton_Click(object sender, RoutedEventArgs e)
            //{
            //    Delete();
            //}

            private void MenuItem_Click(object sender, RoutedEventArgs e)
            {
                MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить все элементы?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    ItemList.Items.Clear();
                }
            }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
    }


